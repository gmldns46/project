var canvasEvents = {
	'12-14-2018' : '<img src="images/ox/true.gif"/>',
	'12-15-2018' : '<img src="images/ox/false.gif"/>'
};