package com.kitri.project.mail;

public interface MemberEmailAuthDao {
	public void createKey(MemberEmailAuth mea);
	public void update(MemberEmailAuth mea);
}
